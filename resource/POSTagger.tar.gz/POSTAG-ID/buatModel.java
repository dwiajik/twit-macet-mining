import java.io.*;
import java.util.*;

public class buatModel{
	
	public static void main(String ar[]){
		
		ArrayList<String> tagset = new ArrayList<String>();
		Hashtable<String,String>tagsetHash = new Hashtable<String,String>();
		int[][] transition = null;
		ArrayList<PairOfWordAndTag> pair = new ArrayList<PairOfWordAndTag>();
		Hashtable<String,String> wordIdx= new Hashtable<String,String>();
		String before = "";
		int bf = -1;
		//String before2 = "";
		//int bf2 = -1;
		
		try{
			
			//baca file tagset
			BufferedReader reader1= 
				new BufferedReader(new InputStreamReader (new FileInputStream ("tagset.txt")));
			
			String line = reader1.readLine().trim();
			while(line != null){
				line = line.trim();
				tagsetHash.put(line, tagset.size()+"");
				tagset.add(line);
				line = reader1.readLine();
			}


			transition = new int[tagset.size()][tagset.size()];
			
			//baca file training
			BufferedReader reader2= 
				new BufferedReader(new InputStreamReader (new FileInputStream ("train.txt")));
			
			String line2 = reader2.readLine().trim();
			while(line2 != null){
				
				line2 = line2.trim();
				
				if(!line2.equals("")){
					StringTokenizer strtok = new StringTokenizer(line2);
					String w = strtok.nextToken().trim().toLowerCase(); 
					String t = strtok.nextToken().trim(); 
					
					int idxT = Integer.parseInt(tagsetHash.get(t));
					
					//transition table
					if(!before.equals("") && bf != -1)
						transition[idxT][bf]++;						

					//swap
					//String tmp1 = before;
					//int tmpi1 = bf;
					
					before = t;
					bf = idxT;
					
					//before2 = tmp1;
					//bf2 = tmpi1;
					
					//emission table
					if(!wordIdx.containsKey(w)){ 
							int idxW = pair.size();
							PairOfWordAndTag pairTmp = new PairOfWordAndTag(w, tagset.size());
							pairTmp.freq[idxT] = 1;
							wordIdx.put(w, idxW+"");
							pair.add(pairTmp);	
					}
					else{
							String idxTmp = wordIdx.get(w);
							int idxW = Integer.parseInt(idxTmp);
							PairOfWordAndTag pairTmp = pair.get(idxW);
							pairTmp.freq[idxT]++;
					}
				}
				
				line2 = reader2.readLine();
			}
			
			//tampilkan emission table					
			for(int ii = 0; ii < pair.size(); ii++){
				System.out.print(pair.get(ii).word+" ");
				
				/* for(int jj = 0; jj < tagset.size(); jj++)
				{
					System.out.print(tagset.get(jj)+"=");
					System.out.print(pair.get(ii).freq[jj]+"   ");
				} */
				for(int jj=0; jj < tagset.size(); jj++)
				{
					System.out.print(pair.get(ii).freq[jj]+" ");
				}
				System.out.print("\n");
			}
			
			System.out.println("=====");
			
			//tampilkan transition table
			for(int ii = 0; ii < transition.length; ii++){
			
				String tag = tagset.get(ii);
				
				//System.out.print(tag + "  :   ");
				/* for(int jj = 0; jj < transition[0].length; jj ++)
				{
					
					String tag2 = tagset.get(jj);
					System.out.print(tag2+"="+transition[ii][jj]+"  ");
									
				} */
				for(int jj = 0; jj < transition[0].length; jj ++)
				{
					System.out.print(transition[ii][jj]+" ");
				}
				System.out.print("\n");
			}
			

			
		}catch(Exception e){
			e.printStackTrace();	
		}
	}	
}

class PairOfWordAndTag{
	
	String word = "";
	int[] freq = null;

	public PairOfWordAndTag(String word, int size){
		this.word = word;
		freq = new int[size];
	}
}