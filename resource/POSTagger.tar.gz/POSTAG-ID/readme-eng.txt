To run the POSTAG program, do the following :

1. Create file "train.txt" for data training
2. Create file "tagset.txt" containing tagset
3. Create file "test.txt" for tagging
4. Compile using java : javac buatModel.java
5. Do the training process : java buatModel > model.txt
6. Compile the POSTAG program : javac buatTagger.java
7. Run the POSTAG program : java buatTagger > tag.txt
8. The output is written in "tag.txt"
