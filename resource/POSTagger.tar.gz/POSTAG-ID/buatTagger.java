import java.io.*;
import java.util.*;

public class buatTagger
{
	static String[] tags;
	static String[] test;
	
	public static void main(String ar[])
	{
		int i = 0;
		int j = 0;
		ArrayList<String> tagset = new ArrayList<String>();
		ArrayList<String> word = new ArrayList<String>();
		ArrayList<String> testFile = new ArrayList<String>();
		ArrayList<Integer> arr = new ArrayList<Integer>();
		ArrayList<Integer> arr2 = new ArrayList<Integer>();
		ArrayList<ArrayList<Integer>> emission = new ArrayList<ArrayList<Integer>>();
		Hashtable<Integer,Integer> testFileIndex= new Hashtable<Integer,Integer>();
		int[][] transition = null;
		double[][] transitionProbability = null;
		int[] transitionTotal = null;
		double[][] emissionProbability = null;
		int[] emissionTotal = null;
		double[] start = null;

		
		try
		{
			//read tagset
			BufferedReader buff1= new BufferedReader(new InputStreamReader (new FileInputStream ("tagset.txt")));
			String line1 = buff1.readLine().trim();
			while(line1 != null)
			{
				line1 = line1.trim();
				tagset.add(line1);
				line1 = buff1.readLine();
			}
			
			//read model
			transition = new int[tagset.size()][tagset.size()];
			BufferedReader buff = new BufferedReader(new InputStreamReader(new FileInputStream("model.txt")));
			String line = buff.readLine().trim();
			//read emission table
			while(line != null && !line.equals("====="))
			{
				line = line.trim();
				
				if(!line.equals(""))
				{
					StringTokenizer str1 = new StringTokenizer(line, " ");
					word.add(str1.nextToken());
					int temp = 0;
					
					while (str1.hasMoreTokens())
					{
							temp = Integer.parseInt(str1.nextToken());
							arr.add(temp);
					}
					
					emission.add(arr);
					arr = new ArrayList<Integer>();
				}
				line = buff.readLine();
			}
			
			while(line != null)
			{
				line = line.trim();
				
				//read transition table
				if(!line.equals("") && !line.equals("====="))
				{
					StringTokenizer str = new StringTokenizer(line, " ");
					while (str.hasMoreTokens())
					{
						for(j=0;j<tagset.size();j++)
						{
							int temp2 = Integer.parseInt(str.nextToken());
							transition[i][j]=temp2;
						}
						j=0;
					}
					i++;
				}
				
				line = buff.readLine();
			}
			
			//read test file
			BufferedReader buff2 = new BufferedReader(new InputStreamReader(new FileInputStream("test.txt")));
			String line2 = buff2.readLine().trim();
			while(line2 != null)
			{
				line2 = line2.trim();
				testFile.add(line2);
				/*if(!word.contains(line2))
				{
					word.add(line2);
					int temp3=1;
					for(int ii=0;ii<tagset.size();ii++)
					{
						arr2.add(temp3);
					}
					emission.add(arr2);
					arr2 = new ArrayList<Integer>();
				}*/
				line2 = buff2.readLine();
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		//count total for transition table		
		transitionTotal = new int[tagset.size()];
		for(int ii=0;ii<transition.length;ii++)
		{
			int temp =0;
			
			for(int jj=0;jj<transition[0].length;jj++)
			{
				transitionTotal[ii] = temp+transition[ii][jj];
				temp = transitionTotal[ii];
			}
		}
		
		//count total for emission table
		emissionTotal = new int[word.size()];
		for(int ii=0;ii<emission.size();ii++)
		{
			int temp =0;
			
			for(int jj=0;jj<emission.get(ii).size();jj++)
			{
				emissionTotal[ii] = temp+emission.get(ii).get(jj);
				temp = emissionTotal[ii];
			}
		}
		
		//count transition probability
		transitionProbability = new double[tagset.size()][tagset.size()];
		for(int ii=0;ii<transition.length;ii++)
		{
			for(int jj=0;jj<transition[0].length;jj++)
			{
				if(transitionTotal[ii]==0)
				{
					transitionProbability[ii][jj]=0;
				}
				else
				{
					transitionProbability[ii][jj]=((double)transition[ii][jj]/(double)transitionTotal[ii]);
				}
			}
		}
		
		//count emission probability
		emissionProbability = new double[tagset.size()][word.size()];
		for(int ii=0;ii<emission.get(0).size();ii++)
		{
			for(int jj=0;jj<word.size();jj++)
			{
				if(emissionTotal[jj]==0)
				{
					emissionProbability[ii][jj]=0;
				}
				else
				{
					emissionProbability[ii][jj]=((double)emission.get(jj).get(ii)/(double)emissionTotal[jj]);
				}
			}
		}
		
		for(int ii=0;ii<testFile.size();ii++)
		{
			for(int jj=0;jj<word.size();jj++)
			{
				if(testFile.get(ii).equals(word.get(jj)))
				{
					testFileIndex.put(ii, jj);
				}
			}
		}
		
		//define tags, test, and start for forward viterbi method
		tags = new String[tagset.size()];
		for(int ii=0;ii<tagset.size();ii++)
		{
			tags[ii] = (String)tagset.get(ii);
		}
		
		test = new String[testFile.size()];
		for(int ii=0;ii<testFile.size();ii++)
		{
			test[ii] = (String)testFile.get(ii);
		}
		
		start = new double[tagset.size()];
		for(int ii=0;ii<tagset.size();ii++)
		{
			start[ii] = 1.0;
		}
		
		//printComponent(test, tags, start, transitionProbability, emissionProbability);
		forwardViterbi(test, tags, start, transitionProbability, emissionProbability, testFileIndex);
	}
	
	//print all components for debugging
	public static void printComponent(String[] tst, String[] tgs, double[] st, double[][] trp, double[][] emp)
	{
		System.out.print("\nStates: ");
		for (int ii = 0; ii < tgs.length; ii++){
			System.out.print(tgs[ii] + ", ");  
		}
		System.out.print("\n\nObservations: ");
		for (int ii = 0; ii < tst.length; ii++){
			System.out.print(tst[ii] + ", ");  
		}
		System.out.print("\n\nStart probability: ");
		for (int ii = 0; ii < st.length; ii++){
			System.out.print(tgs[ii] + ": " + st[ii] + ", ");  
		}
		System.out.println("\n\nTransition probability:");
		for (int ii = 0; ii < tgs.length; ii++){
			System.out.print(" " + tgs[ii] + ": {");
			for (int jj = 0; jj < tgs.length; jj++){
				System.out.print("  " + tgs[jj] + ": " + trp[ii][jj] + ", ");  
			}
			System.out.println("}");
		}
		System.out.println("\n\nEmission probability:");
		for (int ii = 0; ii < tgs.length; ii++){
			System.out.print(" " + tgs[ii] + ": {");
			for (int jj = 0; jj < tst.length; jj++){
				System.out.print("  " + tst[jj] + ": " + emp[ii][jj] + ", ");  
			}
			System.out.println("}");
		}
	}
	
	private static int[] copyIntArray(int[] ia)
	{
		int[] newIa = new int[ia.length];
		for(int i=0; i<ia.length; i++)
		{
			newIa[i] = ia[i];
		}
		return newIa;
	}
	  
	private static int[] copyIntArray(int[] ia, int newInt)
	{
		int[] newIa = new int[ia.length + 1];
		for(int i=0; i<ia.length; i++)
		{
			newIa[i] = ia[i];
		}
		newIa[ia.length] = newInt;
		return newIa;
	}
	
	//forward viterbi method
	// forwardViterbi(observations, states, start_probability, transition_probability, emission_probability)
	public static void forwardViterbi(String[] y, String[] X, double[] sp, double[][] tp, double[][] ep, Hashtable<Integer,Integer> idx) 
	{
		TNode[] T = new TNode[X.length];
		for(int state=0; state<X.length; state++)
		{
			int[] intArray = new int[1];
			intArray[0] = state;
			T[state] = new TNode(sp[state], intArray, sp[state]);
		}
	    
		for(int output=0; output<y.length; output++)
		{
			TNode[] U = new TNode[X.length];
			for(int next_state=0; next_state<X.length; next_state++)
			{
				double total = 0;
				int[] argmax = new int[0];
				double valmax = 0;
				for(int state=0; state<X.length; state++)
				{
					double prob = T[state].prob;
					int[] v_path = copyIntArray(T[state].v_path);
					double v_prob = T[state].v_prob;
					double p = ep[state][idx.get(output)] * tp[next_state][state];				
					prob *= p;
					v_prob *= p;
					total += prob;
					if(v_prob>valmax)
					{
						argmax = copyIntArray(v_path, next_state);
						valmax = v_prob;
					}
				}
				U[next_state] = new TNode(total, argmax, valmax);
			}
			T = U;
		}
		// apply sum/max to the final states:
		double total = 0;
		int[] argmax = new int[0];
		double valmax = 0;
		for(int state=0; state<X.length; state++)
		{
			double prob = T[state].prob;
			int[] v_path = copyIntArray(T[state].v_path);
			double v_prob = T[state].v_prob;
			total += prob;
			if(v_prob>valmax)
			{
				argmax = copyIntArray(v_path);
				valmax = v_prob;
			}
		}
	    
		for(int i = 0; i<argmax.length-1; i++)
		{
			System.out.println(y[i]+" "+tags[argmax[i]]);  
		}
		return;
	}
	
	//define TNode
	private static class TNode
	{
		public double prob;
		public int[] v_path;
		public double  v_prob;
		public TNode(double prob, int[] v_path, double v_prob)
		{
			this.prob = prob;
			this.v_path = copyIntArray(v_path);
			this.v_prob = v_prob;
		}
	}
	
}
